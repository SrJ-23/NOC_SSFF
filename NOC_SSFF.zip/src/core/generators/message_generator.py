"""Generador de mensajes de WhatsApp formateados para las incidencias."""

from __future__ import annotations

import re
from datetime import timedelta
from src.core.models import Incidencia, Plano, EstadoIncidencia, TipoIncidencia


def generate_whatsapp_message(
    incidencia: Incidencia,
    plano: Plano | None,
    bosf_telefono: str | None = None
) -> str:
    """
    Genera el mensaje de WhatsApp para incidencias individuales o masivas de Anillo/Troncal.
    """
    # Formatear fechas y horas de inicio
    fecha_str = incidencia.hora_inicio.strftime("%d/%m/%Y")
    hora_str = incidencia.hora_inicio.strftime("%H:%M")

    # Extraer campos geográficos del Plano (o fallback a incidencia)
    distrito = plano.distrito if plano else incidencia.distrito
    departamento = plano.departamento if plano else incidencia.departamento
    provincia = plano.provincia if plano else incidencia.provincia
    cmts_olt = plano.cmts_olt if plano else ""

    bosf_name = incidencia.bosf or "Pendiente"
    telefono_str = f"-{bosf_telefono}" if bosf_telefono else ""
    telefono_ind_str = f" -{bosf_telefono}" if bosf_telefono else ""
    inc_code = incidencia.inc or "EN PROCESO"

    # Determinar si es una Incidencia Masiva (2 o más planos / distritos agrupados)
    anillo_match = re.search(r"Anillo:\s*([^\n]+)", incidencia.observaciones)
    distritos_detalle_match = re.search(r"Detalle_Distritos:\s*([^\n]+)", incidencia.observaciones)
    planos_match = re.search(r"Planos:\s*([^\n]+)", incidencia.observaciones)
    
    es_masiva_hfc = False
    if incidencia.tipo == TipoIncidencia.HFC:
        if planos_match:
            planos_items = [p.strip() for p in planos_match.group(1).split(",") if p.strip()]
            if len(planos_items) >= 2:
                es_masiva_hfc = True

    # Determinar si está cerrada
    is_closed = incidencia.estado == EstadoIncidencia.CERRADA

    # Parsear historia desde observaciones
    historia_lines = []
    for line in incidencia.observaciones.split('\n'):
        match = re.search(r"^\[(\d{2}:\d{2})\s*h?\]\s*(.*)", line.strip())
        if match:
            hora_val = match.group(1)
            desc_val = match.group(2)
            # Limpiar prefijos ACTUALIZACION/CIERRE
            desc_val = re.sub(r"^(ACTUALIZACION|CIERRE):\s*", "", desc_val, flags=re.IGNORECASE)
            desc_val = desc_val.strip()
            historia_lines.append(f"*{hora_val} h {desc_val}")

    historia_lines.reverse()
    if not any("Se deriva a BOSF" in l for l in historia_lines):
        dt_primera_act = incidencia.hora_inicio + timedelta(minutes=5)
        hora_derivacion_str = dt_primera_act.strftime("%H:%M")
        historia_lines.append(f"*{hora_derivacion_str} h Se deriva a BOSF {bosf_name} para su atención.")
    else:
        # Si la derivación inicial tenía la misma hora que hora_inicio, ajustarla a +5 min
        hora_inicio_str = incidencia.hora_inicio.strftime("%H:%M")
        for idx, l in enumerate(historia_lines):
            if f"*{hora_inicio_str}" in l and "Se deriva a BOSF" in l:
                dt_primera_act = incidencia.hora_inicio + timedelta(minutes=5)
                nueva_hora = dt_primera_act.strftime("%H:%M")
                historia_lines[idx] = re.sub(rf"^\*{hora_inicio_str}\s*h?\s*", f"*{nueva_hora} h ", l)

    history_block = "\n".join(historia_lines)

    hora_solucion_dt = incidencia.hora_inicio + timedelta(hours=4)
    fecha_solucion_str = hora_solucion_dt.strftime("%d/%m/%Y")
    hora_solucion_str = hora_solucion_dt.strftime("%H:%M")

    if is_closed:
        fecha_solucion_str = incidencia.ultima_actualizacion.strftime("%d/%m/%Y")
        hora_solucion_str = incidencia.ultima_actualizacion.strftime("%H:%M")

    fecha_impacto_str = incidencia.ultima_actualizacion.strftime("%d/%m/%Y")
    hora_impacto_str = incidencia.ultima_actualizacion.strftime("%H:%M")

    # =========================================================================
    # FORMATO 1: INCIDENCIA MASIVA HFC (AGRUPA 2 O MÁS PLANOS)
    # =========================================================================
    if es_masiva_hfc:
        tipo_falla_str = incidencia.tipo_falla or "Corte de Fibra"

        # Construir bloques de distritos
        bloques_distritos = []
        if distritos_detalle_match and distritos_detalle_match.group(1).strip():
            raw_dists = distritos_detalle_match.group(1).split(" | ")
            for d_info in raw_dists:
                d_parts = d_info.split(": ")
                d_name = d_parts[0].strip().upper()
                d_stat = d_parts[1].strip() if len(d_parts) > 1 else ""
                
                m_stat = re.search(r"(\d+)\s*nodos?,\s*(\d+)\s*de\s*(\d+)\s*\(([\d\.]+%?)\)", d_stat, re.IGNORECASE)
                if m_stat:
                    n_nodos = m_stat.group(1)
                    n_afectados = m_stat.group(2)
                    n_total = m_stat.group(3)
                    n_pct = m_stat.group(4)
                    if not n_pct.endswith("%"):
                        n_pct += "%"
                    bloques_distritos.append(
                        f"{d_name}\n*HFC ({n_nodos} NODOS): {n_afectados} clientes de {n_total}  ({n_pct})"
                    )
                else:
                    bloques_distritos.append(f"{d_name}\n*{d_stat}")
        else:
            bloques_distritos.append(f"{distrito.upper()}\n*Afectación general de servicios")

        distritos_texto = "\n \n".join(bloques_distritos)
        if is_closed:
            tipo_msg = "*FINAL / CIERRE*"
        elif len(historia_lines) > 1:
            tipo_msg = "*ACTUALIZACIÓN*"
        else:
            tipo_msg = "*INICIAL*"

        planos_hfc_str = ""
        if planos_match and planos_match.group(1).strip():
            planos_hfc_str = f"\n\n*PLANOS AFECTADOS:*\n{planos_match.group(1).strip()}"

        if is_closed:
            msg = (
                f"*NOC SERVICIOS FIJOS*\n"
                f"TIPO DE MENSAJE: {tipo_msg}\n"
                f"TICKET ASIGNADO: {inc_code}\n\n"
                f"*FALLA:*\n"
                f"{tipo_falla_str} en Departamento de {departamento.upper()} Prov. de {provincia.upper()} Distrito de {distrito.upper()} - {fecha_str} {hora_str} h\n\n"
                f"*IMPACTO ({fecha_impacto_str} {hora_impacto_str} h)*\n\n"
                f"*SIN AFECTACIÓN DE SERVICIOS*\n\n"
                f"*ATIENDE:*            \n"
                f"* BOSF {bosf_name}{telefono_str} con {inc_code}\n\n"
                f"*SOLUCIONADO:*\n"
                f"{fecha_impacto_str}\n"
                f"{history_block}\n\n"
                f"*HORA DE SOLUCIÓN :* {fecha_solucion_str} {hora_solucion_str}h"
                f"{planos_hfc_str}"
            )
        else:
            msg = (
                f"*NOC SERVICIOS FIJOS*\n"
                f"TIPO DE MENSAJE: {tipo_msg}\n"
                f"TICKET ASIGNADO: {inc_code}\n\n"
                f"*FALLA:*\n"
                f"{tipo_falla_str} en Departamento de {departamento.upper()} Prov. de {provincia.upper()} Distrito de {distrito.upper()} - {fecha_str} {hora_str} h\n\n"
                f"*IMPACTO ({fecha_impacto_str} {hora_impacto_str} h)*\n\n"
                f"*AFECTACIÓN DE SERVICIOS FIJOS:*   \n"
                f"1. DEPARTAMENTO DE {departamento.upper()}, PROV. DE {provincia.upper()}\n"
                f"DISTRITO(S):\n"
                f"{distritos_texto}\n\n"
                f"*ATIENDE:*            \n"
                f"* BOSF {bosf_name}{telefono_str} con {inc_code}\n\n"
                f"*ACTUALIZACIÓN:*\n"
                f"{fecha_impacto_str}\n"
                f"{history_block}\n\n"
                f"*HORA DE SOLUCIÓN :* {fecha_solucion_str} {hora_solucion_str}h"
                f"{planos_hfc_str}"
            )
        return msg

    # =========================================================================
    # FORMATO FTTH MASIVA (incidencias tipo FTTH con Planos: en observaciones)
    # =========================================================================
    if incidencia.tipo == TipoIncidencia.FTTH:
        tipo_falla_str = incidencia.tipo_falla or "Caida de OLT FTTH"

        # Verificar si hay una etiqueta personalizada (Troncal / Plano / Anillo) en observaciones
        etiqueta_m = re.search(r"ETIQUETA_FALLA:\s*([^\n]+)", incidencia.observaciones)
        if etiqueta_m and etiqueta_m.group(1).strip():
            val = etiqueta_m.group(1).strip()
            val = re.sub(r"^\((.*)\)$", r"\1", val).strip()  # evitar doble paréntesis si el usuario lo escribe
            plano_display = f" ({val})"
        else:
            # Plano principal (primer plano) para mostrarlo en la linea de falla
            plano_id_ftth = ""
            if planos_match:
                primer_p = planos_match.group(1).split(",")[0].strip()
                plano_id_ftth = re.split(r"\s*\(", primer_p)[0].strip()  # quita "(48)"
            plano_display = f" ({plano_id_ftth})" if plano_id_ftth else ""

        linea_falla = (
            f"{tipo_falla_str} en Departamento de {departamento.upper()}, "
            f"prov. de {provincia.upper()} Distrito de {distrito.upper()}"
            f"{plano_display} - {fecha_str} {hora_str} h"
        )

        # Causa raiz y correctivo (solo si están en observaciones)
        causa_raiz_m = re.search(r"CAUSA_RAIZ:\s*([^\n]+)", incidencia.observaciones)
        correctivo_m = re.search(r"CORRECTIVO:\s*([^\n]+)", incidencia.observaciones)
        lineas_causa = ""
        if causa_raiz_m:
            lineas_causa += f"\n*CAUSA RAIZ: {causa_raiz_m.group(1).upper()}*"
        if correctivo_m:
            lineas_causa += f"\n*CORRECTIVO: {correctivo_m.group(1)}*"

        # Bloque de impacto FTTH por distrito
        bloques_distrito_ftth = []
        if distritos_detalle_match and distritos_detalle_match.group(1).strip():
            raw_dists = distritos_detalle_match.group(1).split(" | ")
            for d_info in raw_dists:
                d_parts = d_info.split(": ")
                d_name = d_parts[0].strip().upper()
                d_stat = d_parts[1].strip() if len(d_parts) > 1 else ""
                m_stat = re.search(
                    r"(\d+)\s*nodos?,\s*(\d+)\s*de\s*(\d+)\s*\(([\d.]+%?)\)",
                    d_stat, re.IGNORECASE
                )
                if m_stat:
                    af = m_stat.group(2)
                    tot = m_stat.group(3)
                    pct = m_stat.group(4)
                    if not pct.endswith("%"):
                        pct += "%"
                    # Si hay solo 1 distrito, omitir la línea DISTRITO: (ya está en el bloque padre)
                    if len(raw_dists) == 1:
                        bloques_distrito_ftth.append(f"*FTTH: {af} clientes de {tot} ({pct})")
                    else:
                        bloques_distrito_ftth.append(f"DISTRITO: {d_name}\n*FTTH: {af} clientes de {tot} ({pct})")
                else:
                    if len(raw_dists) == 1:
                        bloques_distrito_ftth.append(f"*{d_stat}")
                    else:
                        bloques_distrito_ftth.append(f"DISTRITO: {d_name}\n*{d_stat}")
        else:
            # fallback: usar clientes totales de observaciones
            clientes_m = re.search(r"Clientes:\s*(\d+)", incidencia.observaciones)
            clientes_val = clientes_m.group(1) if clientes_m else "?"
            bloques_distrito_ftth.append(f"*FTTH: {clientes_val} clientes")

        distritos_ftth_texto = "\n \n".join(bloques_distrito_ftth)

        # ── Extraer servicios adicionales (HFC / MBTS / Corporativo) ──────
        hfc_adicional_m = re.search(r"HFC_ADICIONAL:\s*([^\n]+)", incidencia.observaciones)
        mbts_adicional_m = re.search(r"MBTS_ADICIONAL:\s*([^\n]+)", incidencia.observaciones)
        corp_adicional_m = re.search(r"CORP_ADICIONAL:\s*([^\n]+)", incidencia.observaciones)

        # HFC: "X nodos, Y afectados, total_hfc=TOTAL"
        hfc_adicional_line = ""
        if hfc_adicional_m:
            hfc_raw = hfc_adicional_m.group(1).strip()
            m_hfc = re.search(r"(\d+)\s*nodos?,\s*(\d+)\s*afectados?,?\s*(?:total_hfc=(\d+))?", hfc_raw, re.IGNORECASE)
            if m_hfc:
                n_nodos = m_hfc.group(1)
                n_afect = int(m_hfc.group(2))
                n_total = int(m_hfc.group(3)) if m_hfc.group(3) else 0
                if n_total > 0:
                    pct = round(n_afect / n_total * 100, 2)
                    hfc_adicional_line = f"\n*HFC ({n_nodos} NODOS): {n_afect} clientes de {n_total} ({pct}%)"
                else:
                    hfc_adicional_line = f"\n*HFC ({n_nodos} NODOS): {n_afect} clientes"

        # MBTS: texto libre directo (sin encabezado auto, solo restaurar pipes → saltos de línea)
        mbts_adicional_block = ""
        if mbts_adicional_m:
            mbts_raw = mbts_adicional_m.group(1).strip().replace(" | ", "\n")
            mbts_adicional_block = (
                f"\n\n*AFECTACIÓN DE SERVICIOS MÓVILES (MBTS)*\n"
                f"{mbts_raw}"
            )

        # Corporativo: texto libre directo (sin encabezado auto)
        corp_adicional_block = ""
        if corp_adicional_m:
            corp_raw = corp_adicional_m.group(1).strip().replace(" | ", "\n")
            corp_adicional_block = (
                f"\n\n*AFECTACIÓN DE SERVICIOS CORPORATIVOS:*\n"
                f"{corp_raw}"
            )

        if is_closed:
            tipo_msg = "*CIERRE*"
            cuerpo_actualizacion = (
                f"*SOLUCIONADO:*\n"
                f"{fecha_impacto_str}\n"
                f"{history_block}"
            )
        elif len(historia_lines) > 1:
            tipo_msg = "*ACTUALIZACION*"
            cuerpo_actualizacion = (
                f"*ACTUALIZACION:*\n"
                f"{fecha_impacto_str}\n"
                f"{history_block}"
            )
        else:
            tipo_msg = "*INICIAL*"
            cuerpo_actualizacion = (
                f"*ACTUALIZACION:*\n"
                f"{fecha_impacto_str}\n"
                f"{history_block}"
            )

        # Bloque FTTH principal: HFC primero, luego FTTH
        if is_closed:
            impacto_block = "*SIN AFECTACION DE SERVICIOS*"
        else:
            # Separar partes: HFC arriba, FTTH abajo
            hfc_part = f"{hfc_adicional_line}\n" if hfc_adicional_line else ""
            impacto_block = (
                f"*AFECTACION DE SERVICIOS FIJOS:*   \n"
                f"1. DEPARTAMENTO DE {departamento.upper()}, PROV. DE {provincia.upper()}\n"
                f"DISTRITO: {distrito.upper()}\n"
                f"{hfc_part}"
                f"{distritos_ftth_texto}"
            ).rstrip()

        msg = (
            f"*NOC SERVICIOS FIJOS*\n"
            f"TIPO DE MENSAJE: {tipo_msg}\n"
            f"TICKET ASIGNADO: {inc_code}\n\n"
            f"*FALLA:*\n"
            f"{linea_falla}{lineas_causa}\n\n"
            f"*IMPACTO ({fecha_impacto_str} {hora_impacto_str} h)*\n\n"
            f"{impacto_block}"
            f"{mbts_adicional_block}"
            f"{corp_adicional_block}\n\n"
            f"*ATIENDE:*            \n"
            f"* BOSF {bosf_name}{telefono_str} con {inc_code}\n\n"
            f"{cuerpo_actualizacion}\n\n"
            f"*HORA DE SOLUCION :* {fecha_solucion_str} {hora_solucion_str}h"
        )
        return msg




    clientes_match = re.search(r"Clientes:\s*(\d+)", incidencia.observaciones)
    clientes = int(clientes_match.group(1)) if clientes_match else 0

    plano_id = plano.plano if plano else ""
    if not plano_id:
        plano_match = re.search(r"Plano:\s*(\S+)", incidencia.observaciones)
        if plano_match:
            plano_id = plano_match.group(1)
        else:
            planos_single_match = re.search(r"Planos:\s*([^,\n(]+)", incidencia.observaciones)
            if planos_single_match:
                plano_id = planos_single_match.group(1).strip()
            else:
                plano_id = incidencia.id

    equipo_match = re.search(r"Equipo:\s*([^\n]+)", incidencia.observaciones)
    equipo_val = cmts_olt or (equipo_match.group(1).strip() if equipo_match else "")
    nodo_display = f"{plano_id}_{equipo_val.upper()}" if equipo_val else plano_id
    tec_str = incidencia.tipo.value if hasattr(incidencia.tipo, "value") else str(incidencia.tipo)

    # Ubicación limpia para individual
    if distrito and departamento and distrito.upper() != departamento.upper():
        ubicacion_falla = f"{distrito.upper()} - {departamento.upper()}"
    else:
        ubicacion_falla = (departamento or distrito or "").upper()

    ubicacion_impacto = (distrito or departamento or "").upper()
    nombre_falla = f"Caída de nodo {tec_str} {plano_id}" if plano_id else f"Incidencia {tec_str}"

    if is_closed:
        msg = (
            f"*NOC - SERVICIOS FIJOS*\n\n"
            f"FALLA: {nombre_falla} en {ubicacion_falla} {fecha_str} {hora_str} h\n\n"
            f"*IMPACTO:* \n"
            f"*SIN AFECTACIÓN DE SERVICIOS*\n"
            f"*Atiende BOSF {bosf_name}{telefono_ind_str} con {inc_code}  \n\n"
            f"*SOLUCIONADO:* \n"
            f"{fecha_solucion_str}\n"
            f"{history_block}\n\n"
            f"*HORA DE SOLUCIÓN:* {fecha_solucion_str} {hora_solucion_str}h"
        )
    else:
        msg = (
            f"*NOC - SERVICIOS FIJOS*\n\n"
            f"FALLA: {nombre_falla} en {ubicacion_falla} {fecha_str} {hora_str} h\n\n"
            f"*IMPACTO:* \n"
            f"*Afectación de {clientes} Clientes {tec_str} en {ubicacion_impacto} (Por caída de nodo: {nodo_display})\n"
            f"*Atiende BOSF {bosf_name}{telefono_ind_str} con {inc_code}  \n\n"
            f"*ACTUALIZACION :* \n"
            f"{fecha_str}\n"
            f"{history_block}\n\n"
            f"*HORA DE SOLUCIÓN:* {fecha_solucion_str} {hora_solucion_str}h"
        )

    return msg
